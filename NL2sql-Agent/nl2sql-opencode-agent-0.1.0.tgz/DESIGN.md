# NL2SQL Agent for OpenCode 设计文档

## 1. 目标

为 OpenCode 增加一个以 **自然语言转 SQL（NL2SQL）** 为核心能力的 Agent。用户通过自然语言描述数据需求，Agent 在多轮交互中完成：

1. 需求澄清与规则初始化（头脑风暴）。
2. 查询拆解与隐含信息挖掘。
3. 基于数据库规则生成可执行的 SQL。
4. 通过知识图谱验证结果合理性。
5. 不合理时向用户确认并重新生成 SQL。

Agent 以 **npm 包 + OpenCode v2 插件** 形式交付，安装后即可在 OpenCode 中作为 `nl2sql` Agent 使用。

## 2. 核心能力拆解

| 阶段 | 使用能力 | 说明 |
|------|----------|------|
| 需求澄清/规则生成 | `brainstorm-beagle`（SkillHub） | 多轮对话，生成数据库专属规则：DDL、别名映射、示例、经验 |
| 查询拆解/隐含挖掘 | `brainstorm-beagle` + 本 Agent 内置提示 | 把模糊 query 拆成多个明确子 query，补全隐含条件 |
| 规则召回 | 本地 Markdown 规则库 + 本地/远程 JSON 知识库 | 通过 `database_id` 关联规则，按 `rule_type` 过滤；RAG Core 模式下按结构化条件检索 |
| SQL 生成 | 本 Agent 内置提示 + 召回规则 | 将自然语言子 query 转换为对应数据库的 SQL |
| SQL 执行 | 多态 SQL Engine（插件内实现） | 根据数据库类型选择 MySQL/PostgreSQL/SQLite 等引擎 |
| 结果验证 | `knowledge-graph-agents`（SkillHub） | 将结果凝练为知识图谱，随机游走判断合理性 |
| 失败处理 | 用户确认/补充信息 | 不合理时询问用户，重新生成 SQL |

## 3. 架构图

```
┌──────────────────────────────────────────────────────────────────────┐
│                        OpenCode 会话层                                │
│   用户输入 ──► nl2sql Agent (system prompt + 本技能 SKILL.md)        │
└──────────────────────────────────────────────────────────────────────┘
                                    │
            ┌───────────────────────┼───────────────────────┐
            ▼                       ▼                       ▼
   ┌────────────────┐    ┌────────────────────┐    ┌──────────────────┐
   │ brainstorm-    │    │  NL2SQL 核心 Skill  │    │ knowledge-graph-│
   │ beagle         │    │  (规则 + 生成 + 引擎) │    │ agents          │
   │ 需求澄清/拆解   │    │                     │    │ 结果验证/游走     │
   └────────────────┘    └────────────────────┘    └──────────────────┘
                                    │
            ┌───────────────────────┼───────────────────────┐
            ▼                       ▼                       ▼
   ┌────────────────┐    ┌────────────────────┐    ┌──────────────────┐
   │ 本地规则 JSON  │    │  RAG Core JSON KB   │    │ 多态 SQL Engine   │
   │  + 聚合 Markdown│    │  (euler-copilot-rag)│    │  MySQL/PostgreSQL  │
   │  rules/*.json  │    │  rules/*.md (检索策略)│    │  /SQLite/...      │
   └────────────────┘    └────────────────────┘    └──────────────────┘
                                    │
                                    ▼
                           ┌─────────────────┐
                           │   目标数据库      │
                           │  (执行 SQL)      │
                           └─────────────────┘
```

## 4. 数据流

### 4.1 初始化（首次连接某个数据库）

1. 用户提交：数据库类型、IP、端口、账号、密码、库名、自然语言诉求。
2. Agent 调用 `brainstorm-beagle` 多轮对话，生成：
   - 相关表 DDL
   - 别名/专用名词映射
   - query→sql 示例
   - 字段经验规则
3. 为数据库配置生成唯一 `database_id`（UUID）。
4. 规则存储二选一：
   - **本地模式**：写入 `skills/nl2sql/rules/<database_id>.json` 和 `skills/nl2sql/rules/<database_id>.md`（聚合 Markdown）。
   - **RAG Core 模式**：将每条规则拆散为 JSON 文档，通过 `POST /json/{kb_id}` 写入 `rag_core` 的 JSON 知识库；本地仅保留 `skills/nl2sql/rules/<database_id>.md`，内容为**检索策略**（如何按 `database_id` / `rule_type` / `table` / `col` / `mapping_type` 召回规则）。
5. 在 `databases.json` 中记录该数据库使用的存储后端：`local` 或 `rag_core`（含 `kb_id`）。

### 4.2 查询（用户输入自然语言 query）

1. Agent 使用 `brainstorm-beagle` 拆解 query，挖掘隐含信息（如“最近”= 时间范围、“高”= 阈值等）。
2. 按 `database_id` 召回规则：
   - `rule_type=ddl` → 表结构
   - `rule_type=mapping` → 别名与关系
   - `rule_type=example` → query→sql 示例
   - `rule_type=experience` → 字段经验
3. 生成候选 SQL。
4. 通过多态 SQL Engine 执行 SQL，获取结果。
5. 将结果关键数据凝练为知识图谱。
6. 使用 `knowledge-graph-agents` 进行随机游走/多跳推理，判断结果合理性。
7. 合理 → 返回 SQL + 结果摘要。
8. 不合理 → 向用户询问缺失/歧义信息，回到第 2 步重新生成。

## 5. 规则存储格式

### 5.1 本地模式

每个数据库对应两个文件：

```
skills/nl2sql/rules/<database_id>.json   # 机器可读规则数组
skills/nl2sql/rules/<database_id>.md     # 聚合 Markdown 规则文档
```

Markdown 内容模板：

```markdown
# Database <database_id>

## DDL

### users
```sql
CREATE TABLE users (...);
```
Description: ...

## Mapping

- type: synonym
  table: users
  col: gender
  description: 字段 1 表示男，2 表示女

## Examples

- query: 查询最近 7 天注册的用户
  sql: SELECT * FROM users WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY);
  tables: [users]

## Experience

- tables: [users]
  description: 女性身高一般不超过 170cm
```

### 5.2 RAG Core 模式

当 `rag_core` 服务可用时，优先将规则拆散为 JSON 知识库存储。每个规则是一个 JSON 文档，通过 `POST /json/{kb_id}` 录入。文档格式：

```json
// ddl
{
  "database_id": "xxx",
  "rule_type": "ddl",
  "table": "users",
  "ddl": "CREATE TABLE users (...)",
  "description": "用户表"
}

// mapping
{
  "database_id": "xxx",
  "rule_type": "mapping",
  "mapping_type": "synonym",
  "table": "users",
  "col": "gender",
  "description": "1 表示男，2 表示女"
}

// example
{
  "database_id": "xxx",
  "rule_type": "example",
  "tables": [{"name": "users", "cols": ["id", "created_at"]}],
  "query": "查询最近 7 天注册的用户",
  "sql": "SELECT * FROM users WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)",
  "description": "按注册时间过滤"
}

// experience
{
  "database_id": "xxx",
  "rule_type": "experience",
  "tables": [{"name": "users", "cols": ["gender", "height"]}],
  "description": "女性身高一般不超过 170cm"
}
```

太长的规则可以拆成多个 JSON 条目，共享同一个 `database_id` 和 `rule_type`。

本地 `skills/nl2sql/rules/<database_id>.md` 在 RAG Core 模式下只保存**检索策略**：

```markdown
# Database <database_id> — RAG Core 检索策略

- 知识库 ID: `<kb_id>`
- 服务地址: `http://localhost:9988`（或配置文件中的 `rag_core_url`）
- 鉴权: `Authorization: Bearer <access_key>`（debug 模式可省略，但创建 KB 时建议带上）

## 召回规则

生成 SQL 时，按 `database_id` 过滤后，再按 `rule_type` 检索：

### 1. 表结构 DDL

- `POST /json/search`
- 逻辑表达式：`database_id == "<database_id>" AND rule_type == "ddl"`
- 语义检索字段：`table`, `description`

### 2. 映射与别名 Mapping

- `POST /json/search`
- 逻辑表达式：`database_id == "<database_id>" AND rule_type == "mapping"`
- 语义检索字段：`col`, `description`, `mapping_type`
- 若 query 涉及特定表，追加 `table == "<table>"` 过滤

### 3. query→sql 示例 Example

- `POST /json/search`
- 逻辑表达式：`database_id == "<database_id>" AND rule_type == "example"`
- 语义检索字段：`query`, `sql`, `description`
- 可使用 `top_k` 取最相似示例

### 4. 字段经验 Experience

- `POST /json/search`
- 逻辑表达式：`database_id == "<database_id>" AND rule_type == "experience"`
- 语义检索字段：`description`, `tables[].name`, `tables[].cols`
- 用于 SQL 生成后的校验与知识图谱验证
```

### 5.3 RAG Core 服务对接要点

- 创建 JSON 类型知识库：`POST /kb`，`meta_data_type: "json"`。
- 写入规则：`POST /json/{kb_id}`，`is_imediate: true` 立即录入。
- 检索规则：`POST /json/search`，`search_json_configs` 支持：
  - `query`：自然语言语义检索。
  - `logical_expression`：结构化过滤（`and` / `or` / `eq` / `ne` / `gt` / `gte` / `lt` / `lte` / `in` 等）。
  - `semantic_keys`：指定字段级语义检索（如 `["table"]`、`["col"]`、`["description"]`）。
  - `top_k` / `ratio`：控制返回数量和关键词/向量混合比例。
- 调试模式固定 access_key：`debug-access-key`。
- 生产模式使用 `Authorization: Bearer <明文密钥>`，并确保 KB 归属一致。

## 6. SQL Engine 多态设计

所有引擎实现统一接口 `SqlEngine`：

```ts
interface SqlEngine {
  id: string;
  execute(sql: string, config: DatabaseConfig): Promise<SqlResult>;
  testConnection(config: DatabaseConfig): Promise<boolean>;
}
```

- 根据 `database_id` 的配置中 `type` 字段选择引擎。
- 内置实现：MySQL、PostgreSQL、SQLite（示例）。
- 用户可扩展：实现 `SqlEngine` 并注册到 `EngineRegistry`。
- 引擎文件位于 `skills/nl2sql/engines/`。

## 7. 知识图谱验证

- 从 SQL 结果中提取关键实体（如用户、订单、时间、数值等）。
- 构建节点和边，形成结果子图。
- 选择种子节点（如 query 中提到的核心实体）。
- 从种子节点进行随机游走/2-hop 推理，检查是否存在明显矛盾：
  - 数值超出经验范围（如女性身高 > 170cm）。
  - 关系缺失（如订单没有对应用户）。
  - 时间冲突（如创建时间晚于更新时间）。
- 发现矛盾 → 记录为 `inconsistency`，向用户询问。

## 8. OpenCode 集成方式

本包为 OpenCode v2 插件，遵循 **skill 原子化**原则：

- `skills/nl2sql/SKILL.md` 只描述 NL2SQL  skill 本身的能力（规则、引擎、SQL 生成、结果格式），不描述与其他 skill 的协同关系。
- `src/role-prompt.md` 描述 `nl2sql` Agent 的协调逻辑：何时调用 `brainstorm-beagle`、何时调用 `nl2sql` skill、何时调用 `knowledge-graph-agents`。
- `brainstorm-beagle` 和 `knowledge-graph-agents` 作为独立 skill 安装，不被修改。

插件入口组合两者作为 Agent 的 system prompt：

```ts
import { define } from "@opencode-ai/plugin/v2/promise";

export default define({
  id: "nl2sql-opencode-agent",
  setup(ctx) {
    // 注册原子化的 NL2SQL skill 目录
    ctx.skill.transform((draft) => {
      draft.source({
        type: "directory",
        path: path.join(__dirname, "../skills/nl2sql"),
      });
    });

    // 注册 nl2sql Agent，system prompt = role-prompt + skill 指令
    ctx.agent.transform((draft) => {
      draft.update("nl2sql", (agent) => {
        agent.system = readFileSync("role-prompt.md") + "\n---\n" + readFileSync("skills/nl2sql/SKILL.md");
        agent.description = "自然语言转 SQL Agent";
      });
    });
  },
});
```

用户在 `~/.config/opencode/opencode.jsonc` 中添加：

```jsonc
{
  "plugin": ["nl2sql-opencode-agent"]
}
```

并安装依赖 skills（已随包附带，也可单独安装）：

```bash
skillhub install brainstorm-beagle --namespace anderskev --dir ~/.config/opencode/skills
skillhub install knowledge-graph-agents --namespace vnesin-sarai --dir ~/.config/opencode/skills
```

## 9. 目录结构

```
nl2sql-agent/
├── DESIGN.md
├── README.md
├── package.json
├── tsconfig.json
├── src/
│   ├── index.ts          # 插件入口
│   ├── role-prompt.md    # nl2sql Agent 的 system prompt（skill 协同编排）
│   ├── config.ts         # 数据库配置读写（database_id 映射）
│   ├── rule-store.ts     # 规则库读写（本地 JSON / RAG Core）
│   └── rag-core.ts       # RAG Core 服务客户端
├── skills/
│   ├── nl2sql/           # 原子化 NL2SQL skill
│   │   ├── SKILL.md      # skill 自身能力说明（不引用其他 skill）
│   │   ├── _meta.json
│   │   ├── engines/      # 多态 SQL 引擎（技能子目录）
│   │   │   ├── index.js
│   │   │   ├── mysql.js
│   │   │   ├── postgres.js
│   │   │   ├── sqlite.js
│   │   │   └── README.md
│   │   └── rules/        # 规则库（本地文件 + RAG Core 检索策略）
│   │       ├── schema.json
│   │       └── README.md
│   ├── @anderskev/brainstorm-beagle
│   └── @vnesin-sarai/knowledge-graph-agents
└── dist/                 # 编译产物
```

## 10. 安全与权限

- 数据库凭据保存在 `~/.config/opencode/nl2sql-agent/databases.json`，文件权限建议 `600`。
- SQL 执行前默认只执行 `SELECT`，禁止 `DROP/DELETE/UPDATE/INSERT` 等写入操作（可在配置中显式开启只读）。
- 所有 SQL 执行前打印到日志，便于审计。
- 连接数据库使用参数化查询，防止 SQL 注入（示例引擎中实现）。

## 11. 后续扩展

- 支持更多数据库引擎（ClickHouse、SQL Server、Oracle 等）。
- 自动 schema 发现：根据数据库连接自动拉取 DDL 生成初始规则。
- 规则版本化：每次规则更新生成版本，支持回滚。
- 在线学习：将用户确认的 query→sql 自动加入 example 规则库。
