# 规则库目录

本目录存储每个数据库对应的 NL2SQL 规则。根据存储后端不同，有两种形态：

## 模式 A：本地存储（默认）

每个数据库对应两个文件：

```
skills/nl2sql/rules/<database_id>.json   # 机器可读的规则数组
skills/nl2sql/rules/<database_id>.md     # 聚合 Markdown 规则文档
```

### 规则类型

| rule_type | 含义 | 关键字段 |
|-----------|------|----------|
| `ddl` | 表结构 | `table`, `ddl` |
| `mapping` | 别名/映射/关系 | `mapping_type`, `table`, `col`, `description` |
| `example` | query→sql 示例 | `query`, `sql`, `tables` |
| `experience` | 字段经验/业务常识 | `description`, `tables` |

### 初始化规则

首次连接数据库时：

1. 通过上层 Agent 的需求澄清流程（多轮对话）确认业务诉求。
2. 拉取相关表的 DDL，生成 `ddl` 规则。
3. 梳理专用名词与自然语言映射，生成 `mapping` 规则。
4. 收集典型 query→sql 示例，生成 `example` 规则。
5. 整理业务经验（如“女性身高一般不超过 170cm”），生成 `experience` 规则。
6. 调用规则库工具写入 `<database_id>.json` 和 `<database_id>.md`。

### 检索规则

生成 SQL 时，按以下优先级召回：

1. 用 `database_id` 过滤出该数据库的所有规则。
2. 按 `rule_type` 分桶：先 `ddl`（表结构），再 `mapping`（语义），再 `example`（相似示例），最后 `experience`（常识校验）。
3. 对 `mapping` 规则，可进一步按 `mapping_type` 和表/字段名过滤。
4. 太长的规则可拆成多个 JSON 条目，通过共享 `database_id` + `rule_type` 聚合。

---

## 模式 B：RAG Core 存储（推荐）

当本地已部署 `euler-copilot-rag/rag_core` 时，优先将规则拆散存入 JSON 知识库，本地 `<database_id>.md` 只保存**检索策略**。

### 规则在 RAG Core 中的存储形态

每个规则是一个 JSON 文档，通过 `POST /json/{kb_id}` 录入，字段与本地模式一致：

```json
{
  "database_id": "xxx",
  "rule_type": "ddl",
  "table": "users",
  "ddl": "CREATE TABLE users (...)",
  "description": "用户表"
}
```

其他类型示例：

- `mapping`：`mapping_type`, `table`, `col`, `description`
- `example`：`query`, `sql`, `tables`
- `experience`：`description`, `tables`

### 初始化步骤

1. 调用 `POST /kb` 创建 JSON 类型知识库，拿到 `kb_id`。
2. 将 `kb_id` 写入数据库配置：`rule_storage = { type: "rag_core", kb_id: "..." }`。
3. 每条规则调用 `POST /json/{kb_id}` 并设置 `is_imediate: true` 立即录入。
4. 本地写入 `<database_id>.md`，内容为**检索策略**（不写原始规则全文）。

### 检索策略（`<database_id>.md`）内容

当规则存入 RAG Core 后，本地 Markdown 文件只包含：

- 知识库 ID (`kb_id`) 和服务地址。
- 鉴权方式（debug 模式可省略，生产模式使用 `Authorization: Bearer <access_key>`）。
- 每种 `rule_type` 的召回逻辑：
  - 逻辑表达式 (`logical_expression`)：按 `database_id` + `rule_type` + `table`/`col`/`mapping_type` 过滤。
  - 语义检索字段 (`semantic_keys`)：如 `description`, `table`, `col`, `query`, `sql`。
  - 推荐 `top_k` / `ratio`。
- 已录入规则的示例摘要（可选）。

### 从 RAG Core 检索规则

请求示例：

```json
POST /json/search
{
  "search_json_configs": [{
    "kb_id": "<kb_id>",
    "query": "用户表 性别 映射",
    "top_k": 10,
    "ratio": 0.3,
    "semantic_keys": [["description"], ["table"], ["col"]],
    "logical_expression": {
      "operator": "and",
      "expressions": [
        { "field": "database_id", "operator": "eq", "value": "<database_id>" },
        { "field": "rule_type", "operator": "eq", "value": "mapping" }
      ]
    }
  }]
}
```

支持的 `operator` 字段包括：`and`, `or`, `eq`, `ne`, `gt`, `gte`, `lt`, `lte`, `in`, `contains`。

- 组合表达式：`{ "operator": "and", "expressions": [...] }`
- 叶子表达式：`{ "field": "xxx", "operator": "eq", "value": "yyy" }`

### 检索策略示例

```markdown
# Database xxx — RAG Core 检索策略

- 知识库 ID: `<kb_id>`
- 服务地址: `http://localhost:9988`
- 鉴权: `Authorization: Bearer <access_key>`

## DDL 召回

- 逻辑表达式：`database_id == "xxx" AND rule_type == "ddl"`
- 语义检索字段：`table`, `description`, `ddl`
- 用于获取表结构。

## Mapping 召回

- 逻辑表达式：`database_id == "xxx" AND rule_type == "mapping"`
- 语义检索字段：`col`, `description`, `mapping_type`
- 若 query 涉及特定表，追加 `table == "..."` 过滤。
```

---

## 存储后端选择建议

| 场景 | 推荐 |
|------|------|
| 无 RAG Core 服务 / 快速体验 | 本地 `local` |
| 规则数量大、需要语义检索 | RAG Core `rag_core` |
| 多 Agent 共享规则库 | RAG Core `rag_core` |
| 需要版本化/权限管理 | 本地 `local` + Git 版本控制 |

---

## 与 RAG Core 服务集成

- 服务地址：默认 `http://localhost:9988`（可在 `~/.config/opencode/nl2sql-agent/rag-core.json` 中配置 `baseUrl` 和 `accessKey`）。
- 创建 KB：`POST /kb`，`meta_data_type: "json"`。
- 写入规则：`POST /json/{kb_id}`，`is_imediate: true`。
- 检索规则：`POST /json/search`，使用 `logical_expression` + `semantic_keys`。
- 调试模式固定 access_key：`debug-access-key`。
- 生产模式使用 `Authorization: Bearer <明文密钥>`，并确保 KB 归属一致。
