#!/usr/bin/env node
/**
 * NL2SQL SQL Engine CLI
 *
 * 用法：
 *   node engines/index.js run <database_id> "<sql>"
 *   node engines/index.js test <database_id>
 *   node engines/index.js list
 *
 * 数据库配置读取 ~/.config/opencode/nl2sql-agent/databases.json
 */

import { existsSync, readFileSync } from "node:fs";
import { homedir } from "node:os";
import path from "node:path";

const CONFIG_FILE = path.join(
  homedir(),
  ".config/opencode/nl2sql-agent/databases.json"
);

const registry = {};

async function loadEngines() {
  const dir = path.dirname(new URL(import.meta.url).pathname);
  const files = ["mysql.js", "postgres.js", "sqlite.js"];
  for (const file of files) {
    try {
      const mod = await import(path.join(dir, file));
      const engine = mod.default || mod;
      if (engine && engine.id) {
        registry[engine.id] = engine;
      }
    } catch (err) {
      console.warn(`[nl2sql-engine] failed to load ${file}: ${err.message}`);
    }
  }
}

function loadConfig(id) {
  if (!existsSync(CONFIG_FILE)) {
    throw new Error(`Database config file not found: ${CONFIG_FILE}`);
  }
  const all = JSON.parse(readFileSync(CONFIG_FILE, "utf-8"));
  const cfg = all[id];
  if (!cfg) {
    throw new Error(`Database config not found: ${id}`);
  }
  return cfg;
}

async function main() {
  await loadEngines();
  const [cmd, id, ...rest] = process.argv.slice(2);

  if (cmd === "list") {
    console.log(JSON.stringify(Object.keys(registry), null, 2));
    return;
  }

  if (cmd === "test") {
    const cfg = loadConfig(id);
    const engine = registry[cfg.type];
    if (!engine) throw new Error(`Unsupported engine type: ${cfg.type}`);
    const ok = await engine.testConnection(cfg);
    console.log(JSON.stringify({ ok }, null, 2));
    return;
  }

  if (cmd === "run") {
    const sql = rest.join(" ");
    if (!sql) throw new Error("Missing SQL");
    const cfg = loadConfig(id);
    const engine = registry[cfg.type];
    if (!engine) throw new Error(`Unsupported engine type: ${cfg.type}`);

    if (cfg.readonly !== false) {
      const normalized = sql.trim().toLowerCase();
      if (
        !normalized.startsWith("select") &&
        !normalized.startsWith("with") &&
        !normalized.startsWith("show") &&
        !normalized.startsWith("explain")
      ) {
        throw new Error(
          `Only read-only SQL is allowed by default. Set readonly=false to enable writes. SQL: ${sql}`
        );
      }
    }

    const result = await engine.execute(sql, cfg);
    console.log(JSON.stringify(result, null, 2));
    return;
  }

  console.log(`Usage: node engines/index.js <list|test <id>|run <id> <sql>>`);
  process.exit(1);
}

main().catch((err) => {
  console.error(JSON.stringify({ error: err.message }, null, 2));
  process.exit(1);
});
