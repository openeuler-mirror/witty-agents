import Database from "better-sqlite3";

export default {
  id: "sqlite",

  async testConnection(config) {
    const db = new Database(config.file || config.database || ":memory:");
    try {
      db.prepare("SELECT 1").get();
      return true;
    } finally {
      db.close();
    }
  },

  async execute(sql, config) {
    const db = new Database(config.file || config.database || ":memory:");
    try {
      const stmt = db.prepare(sql);
      let rows;
      const lower = sql.trim().toLowerCase();
      if (lower.startsWith("select") || lower.startsWith("with")) {
        rows = stmt.all();
      } else {
        const info = stmt.run();
        rows = [{ changes: info.changes, lastInsertRowid: info.lastInsertRowid }];
      }
      return {
        rows: Array.isArray(rows) ? rows.slice(0, 1000) : rows,
        rowCount: Array.isArray(rows) ? rows.length : undefined,
      };
    } finally {
      db.close();
    }
  },
};
