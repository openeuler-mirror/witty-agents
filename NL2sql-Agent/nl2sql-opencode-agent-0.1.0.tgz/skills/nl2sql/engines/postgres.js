import pg from "pg";
const { Client } = pg;

export default {
  id: "postgres",

  async testConnection(config) {
    const client = new Client({
      host: config.host,
      port: config.port || 5432,
      user: config.username,
      password: config.password,
      database: config.database,
      ...(config.options || {}),
    });
    await client.connect();
    try {
      await client.query("SELECT 1");
      return true;
    } finally {
      await client.end();
    }
  },

  async execute(sql, config) {
    const client = new Client({
      host: config.host,
      port: config.port || 5432,
      user: config.username,
      password: config.password,
      database: config.database,
      ...(config.options || {}),
    });
    await client.connect();
    try {
      const result = await client.query(sql);
      return {
        rows: result.rows?.slice(0, 1000) || [],
        fields: result.fields?.map((f) => ({ name: f.name, type: f.dataTypeID })) || [],
        rowCount: result.rowCount,
      };
    } finally {
      await client.end();
    }
  },
};
