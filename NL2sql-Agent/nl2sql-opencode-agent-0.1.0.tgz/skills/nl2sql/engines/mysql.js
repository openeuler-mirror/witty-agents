import mysql from "mysql2/promise";

export default {
  id: "mysql",

  async testConnection(config) {
    const conn = await mysql.createConnection({
      host: config.host,
      port: config.port || 3306,
      user: config.username,
      password: config.password,
      database: config.database,
      ...(config.options || {}),
    });
    try {
      await conn.execute("SELECT 1");
      return true;
    } finally {
      await conn.end();
    }
  },

  async execute(sql, config) {
    const conn = await mysql.createConnection({
      host: config.host,
      port: config.port || 3306,
      user: config.username,
      password: config.password,
      database: config.database,
      ...(config.options || {}),
    });
    try {
      const [rows, fields] = await conn.execute(sql);
      return {
        rows: Array.isArray(rows) ? rows.slice(0, 1000) : rows,
        fields: fields?.map((f) => ({ name: f.name, type: String(f.type) })) || [],
        rowCount: Array.isArray(rows) ? rows.length : undefined,
      };
    } finally {
      await conn.end();
    }
  },
};
