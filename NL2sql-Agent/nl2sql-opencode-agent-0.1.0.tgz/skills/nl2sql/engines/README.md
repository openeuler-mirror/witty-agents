# SQL Engine 目录

本目录存放 NL2SQL Agent 的多态数据库引擎实现。每个引擎文件导出一个对象，包含：

- `id`: 数据库类型标识（如 `mysql`、`postgres`、`sqlite`）。
- `testConnection(config)`: 测试连接是否可用。
- `execute(sql, config)`: 执行 SQL 并返回 `{ rows, fields?, rowCount? }`。

## 内置引擎

- `mysql.js`: MySQL 引擎，使用 `mysql2/promise`。
- `postgres.js`: PostgreSQL 引擎，使用 `pg`。
- `sqlite.js`: SQLite 引擎，使用 `better-sqlite3`。

## 新增引擎

新建文件（如 `clickhouse.js`），实现上述接口，并在 `index.js` 的 `loadEngines` 文件列表中注册即可。

## CLI 使用

```bash
# 查看可用引擎
node skills/nl2sql/engines/index.js list

# 测试连接
node skills/nl2sql/engines/index.js test my-db-001

# 执行 SQL（只读，默认限制）
node skills/nl2sql/engines/index.js run my-db-001 "SELECT COUNT(*) FROM users"
```

数据库配置读取 `~/.config/opencode/nl2sql-agent/databases.json`。
