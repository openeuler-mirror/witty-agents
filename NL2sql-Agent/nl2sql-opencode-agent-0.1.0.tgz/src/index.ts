import { define } from "@opencode-ai/plugin/v2/promise";
import { readFileSync, readdirSync, statSync, existsSync } from "node:fs";

const __dirname = dirname(fileURLToPath(import.meta.url));
const skillsRoot = join(__dirname, "../skills");

const systemPrompt = [
  readFileSync(join(__dirname, "role-prompt.md"), "utf-8"),
  "---",
  "# nl2sql skill instructions",
  readFileSync(join(skillsRoot, "nl2sql/SKILL.md"), "utf-8"),
].join("\n\n");

function discoverSkillDirs(root: string): string[] {
  const dirs: string[] = [];
  for (const entry of readdirSync(root)) {
    const full = join(root, entry);
    if (!statSync(full).isDirectory()) continue;
    if (entry.startsWith(".")) continue;
    // Direct skill directory (contains SKILL.md)
    if (existsSync(join(full, "SKILL.md"))) {
      dirs.push(full);
      continue;
    }
    // Namespaced skill directories (e.g., @anderskev/brainstorm-beagle)
    for (const nsEntry of readdirSync(full)) {
      const nsFull = join(full, nsEntry);
      if (statSync(nsFull).isDirectory() && existsSync(join(nsFull, "SKILL.md"))) {
        dirs.push(nsFull);
      }
    }
  }
  return dirs;
}

export default define({
  id: "nl2sql-opencode-agent",
  async setup(ctx) {
    // Register all bundled skill directories as independent atomic skills.
    for (const dir of discoverSkillDirs(skillsRoot)) {
      ctx.skill.transform((draft) => {
        draft.source({
          type: "directory",
          path: dir,
        });
      });
    }

    // Register the nl2sql primary agent.
    ctx.agent.transform((draft) => {
      draft.update("nl2sql", (agent) => {
        agent.system = systemPrompt;
        agent.description =
          "自然语言转 SQL Agent：支持规则初始化、查询拆解、SQL 生成、执行与知识图谱验证。";
        agent.mode = "primary";
        agent.hidden = false;
        agent.color = "info";
      });
    });

    // Register a simple command to manage database configs.
    ctx.command.transform((draft) => {
      draft.update("nl2sql-config", (cmd) => {
        cmd.template = "Manage nl2sql database configs: add | list | remove <id> | init-rules <id>";
        cmd.description = "Add/list/remove database configurations for nl2sql agent";
        cmd.agent = "nl2sql";
      });
    });

    // Ensure helper singletons are initialized so config/rule directories exist.
    DatabaseConfigManager.getInstance();
    RuleStore.getInstance();
  },
});

export { DatabaseConfigManager, RuleStore, RagCoreClient };
