import { existsSync, readFileSync } from "node:fs";
import { homedir } from "node:os";
import path from "node:path";

const RAG_CONFIG_FILE = path.join(
  homedir(),
  ".config/opencode/nl2sql-agent/rag-core.json"
);

export interface RagCoreConfig {
  baseUrl: string;
  accessKey?: string;
  kbId?: string;
}

export interface RagCoreRuleDocument {
  name: string;
  content: Record<string, unknown>;
  is_imediate?: boolean;
}

export interface SearchJsonConfig {
  kb_id: string;
  query?: string;
  top_k?: number;
  ratio?: number;
  semantic_keys?: string[][];
  logical_expression?: LogicalExpression;
}

export interface LogicalExpression {
  operator?: "and" | "or" | "eq" | "ne" | "gt" | "gte" | "lt" | "lte" | "in" | "contains";
  field?: string;
  value?: unknown;
  expressions?: LogicalExpression[];
}

export class RagCoreClient {
  private config: RagCoreConfig;

  constructor(config?: Partial<RagCoreConfig>) {
    this.config = config ? { ...this.loadFile(), ...config } : this.loadFile();
  }

  private loadFile(): RagCoreConfig {
    if (!existsSync(RAG_CONFIG_FILE)) {
      return { baseUrl: "http://localhost:9988" };
    }
    try {
      return JSON.parse(readFileSync(RAG_CONFIG_FILE, "utf-8")) as RagCoreConfig;
    } catch {
      return { baseUrl: "http://localhost:9988" };
    }
  }

  private headers(): Record<string, string> {
    const h: Record<string, string> = { "Content-Type": "application/json" };
    if (this.config.accessKey) {
      h["Authorization"] = `Bearer ${this.config.accessKey}`;
    }
    return h;
  }

  private async fetchJson(url: string, init: RequestInit): Promise<unknown> {
    const res = await fetch(url, { ...init, headers: this.headers() });
    const text = await res.text();
    let json: unknown;
    try {
      json = JSON.parse(text);
    } catch {
      json = { raw: text };
    }
    if (!res.ok) {
      throw new Error(
        `RAG Core request failed: ${res.status} ${res.statusText} → ${JSON.stringify(json)}`
      );
    }
    return json;
  }

  /**
   * Create a JSON-type knowledge base.
   */
  async createKb(name: string, description?: string): Promise<string> {
    const url = new URL("/kb", this.config.baseUrl).toString();
    const body = {
      name,
      description: description || `NL2SQL rules for ${name}`,
      meta_data_type: "json",
    };
    const result = (await this.fetchJson(url, {
      method: "POST",
      body: JSON.stringify(body),
    })) as { kb_id?: string; id?: string } | undefined;
    const kbId = result?.kb_id || result?.id;
    if (!kbId) {
      throw new Error(`Failed to create KB: ${JSON.stringify(result)}`);
    }
    this.config.kbId = kbId;
    return kbId;
  }

  /**
   * Add a single JSON rule document to the KB (immediately indexed).
   */
  async addRule(kbId: string, rule: Record<string, unknown>): Promise<unknown> {
    const url = new URL(`/json/${kbId}`, this.config.baseUrl).toString();
    const doc: RagCoreRuleDocument = {
      name: String(rule.rule_type || "rule") + "-" + String(rule.id || Date.now()),
      content: rule,
      is_imediate: true,
    };
    return this.fetchJson(url, {
      method: "POST",
      body: JSON.stringify(doc),
    });
  }

  /**
   * Search rules by database_id and optional rule_type / table / col.
   */
  async searchRules(
    kbId: string,
    databaseId: string,
    filters?: {
      rule_type?: string;
      table?: string;
      col?: string;
      mapping_type?: string;
      query?: string;
      top_k?: number;
      semantic_keys?: string[][];
    }
  ): Promise<Record<string, unknown>[]> {
    const expressions: LogicalExpression[] = [
      {
        field: "database_id",
        operator: "eq",
        value: databaseId,
      },
    ];
    if (filters?.rule_type) {
      expressions.push({
        field: "rule_type",
        operator: "eq",
        value: filters.rule_type,
      });
    }
    if (filters?.table) {
      expressions.push({
        field: "table",
        operator: "eq",
        value: filters.table,
      });
    }
    if (filters?.col) {
      expressions.push({
        field: "col",
        operator: "eq",
        value: filters.col,
      });
    }
    if (filters?.mapping_type) {
      expressions.push({
        field: "mapping_type",
        operator: "eq",
        value: filters.mapping_type,
      });
    }

    const logicalExpression: LogicalExpression =
      expressions.length === 1
        ? expressions[0]
        : { operator: "and", expressions };

    const searchConfig: SearchJsonConfig = {
      kb_id: kbId,
      query: filters?.query || "",
      top_k: filters?.top_k || 10,
      ratio: 0.3,
      semantic_keys: filters?.semantic_keys || [["description"], ["table"], ["col"], ["query"], ["sql"]],
      logical_expression: logicalExpression,
    };

    const url = new URL("/json/search", this.config.baseUrl).toString();
    const result = (await this.fetchJson(url, {
      method: "POST",
      body: JSON.stringify({ search_json_configs: [searchConfig] }),
    })) as { results?: Array<{ content?: Record<string, unknown> }> } | undefined;

    return (result?.results || []).map((r) => r.content || {});
  }

  getConfig(): RagCoreConfig {
    return this.config;
  }
}
