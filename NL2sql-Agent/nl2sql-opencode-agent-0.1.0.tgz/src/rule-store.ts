import { existsSync, mkdirSync, readFileSync, readdirSync, writeFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { v4 as uuidv4 } from "uuid";
import { RagCoreClient } from "./rag-core.js";
import type { DatabaseConfig } from "./config.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const RULES_DIR = path.join(__dirname, "../skills/nl2sql/rules");

export type RuleType = "ddl" | "mapping" | "example" | "experience";

export interface RuleBase {
  id: string;
  database_id: string;
  rule_type: RuleType;
  description?: string;
}

export interface DdlRule extends RuleBase {
  rule_type: "ddl";
  table: string;
  ddl: string;
}

export interface MappingRule extends RuleBase {
  rule_type: "mapping";
  mapping_type:
    | "causality"
    | "correlation"
    | "dependency"
    | "correspondence"
    | "interaction"
    | "parallel"
    | "alternative"
    | "synonym"
    | "antonym"
    | "contrast"
    | "composition"
    | "inheritance"
    | "ownership"
    | "sufficient-condition"
    | "necessary-condition"
    | "sufficient-and-necessary-condition"
    | "mutual-exclusion"
    | "contradiction"
    | "temporal-sequence"
    | "progression"
    | "evolution"
    | "transition"
    | "concession"
    | "exemplification"
    | "explanation";
  table?: string;
  col?: string;
  from?: string;
  to?: string;
  description: string;
}

export interface ExampleRule extends RuleBase {
  rule_type: "example";
  tables?: Array<{ name?: string; cols?: string[] }>;
  query: string;
  sql: string;
}

export interface ExperienceRule extends RuleBase {
  rule_type: "experience";
  tables?: Array<{ name?: string; cols?: string[] }>;
  description: string;
}

export type Rule = DdlRule | MappingRule | ExampleRule | ExperienceRule;

export class RuleStore {
  private static instance: RuleStore;
  private ragClient: RagCoreClient;

  private constructor() {
    if (!existsSync(RULES_DIR)) {
      mkdirSync(RULES_DIR, { recursive: true });
    }
    this.ragClient = new RagCoreClient();
  }

  static getInstance(): RuleStore {
    if (!RuleStore.instance) {
      RuleStore.instance = new RuleStore();
    }
    return RuleStore.instance;
  }

  private jsonPath(databaseId: string): string {
    return path.join(RULES_DIR, `${databaseId}.json`);
  }

  private mdPath(databaseId: string): string {
    return path.join(RULES_DIR, `${databaseId}.md`);
  }

  /**
   * List rules for a database.
   * In local mode, reads the JSON file. In rag_core mode, queries the RAG Core service.
   */
  async list(databaseId: string, config?: DatabaseConfig): Promise<Rule[]> {
    const backend = config?.rule_storage?.type || "local";

    if (backend === "rag_core") {
      const kbId = config?.rule_storage?.kb_id;
      if (!kbId) throw new Error(`Missing kb_id for RAG Core rule storage (database_id=${databaseId})`);
      const docs = await this.ragClient.searchRules(kbId, databaseId, { top_k: 100 });
      return docs as Rule[];
    }

    const p = this.jsonPath(databaseId);
    if (!existsSync(p)) return [];
    try {
      return JSON.parse(readFileSync(p, "utf-8")) as Rule[];
    } catch {
      return [];
    }
  }

  /**
   * Filter rules by rule_type and optional semantic fields.
   */
  async filter(
    databaseId: string,
    config: DatabaseConfig | undefined,
    ruleType?: RuleType,
    options?: { table?: string; col?: string; mapping_type?: string; query?: string; top_k?: number }
  ): Promise<Rule[]> {
    const backend = config?.rule_storage?.type || "local";

    if (backend === "rag_core") {
      const kbId = config?.rule_storage?.kb_id;
      if (!kbId) throw new Error(`Missing kb_id for RAG Core rule storage (database_id=${databaseId})`);
      const docs = await this.ragClient.searchRules(kbId, databaseId, {
        rule_type: ruleType,
        table: options?.table,
        col: options?.col,
        mapping_type: options?.mapping_type,
        query: options?.query,
        top_k: options?.top_k || 10,
      });
      return docs as Rule[];
    }

    const rules = await this.list(databaseId, config);
    return ruleType ? rules.filter((r) => r.rule_type === ruleType) : rules;
  }

  /**
   * Add a rule. In local mode, writes to JSON + Markdown. In rag_core mode, pushes to RAG Core KB
   * and writes a retrieval-strategy Markdown file locally.
   */
  async add(
    databaseId: string,
    config: DatabaseConfig | undefined,
    rule: Omit<Rule, "id" | "database_id">
  ): Promise<Rule> {
    const full = { ...rule, id: uuidv4(), database_id: databaseId } as Rule;
    const backend = config?.rule_storage?.type || "local";

    if (backend === "rag_core") {
      const kbId = config?.rule_storage?.kb_id;
      if (!kbId) throw new Error(`Missing kb_id for RAG Core rule storage (database_id=${databaseId})`);
      await this.ragClient.addRule(kbId, full as Record<string, unknown>);
      await this.writeRetrievalStrategyMarkdown(databaseId, config, [full]);
      return full;
    }

    const rules = (await this.list(databaseId, config)) as Rule[];
    rules.push(full);
    this.saveJson(databaseId, rules);
    this.saveMarkdown(databaseId, rules);
    return full;
  }

  /**
   * Initialize RAG Core rule storage: create a JSON KB and patch the database config.
   */
  async initRagCoreStorage(
    databaseId: string,
    config: DatabaseConfig,
    kbName?: string
  ): Promise<DatabaseConfig> {
    const kbId = await this.ragClient.createKb(
      kbName || `nl2sql-rules-${databaseId}`,
      `NL2SQL rules for database ${databaseId}`
    );
    const updated: DatabaseConfig = {
      ...config,
      rule_storage: { type: "rag_core", kb_id: kbId },
    };
    await this.writeRetrievalStrategyMarkdown(databaseId, updated, []);
    return updated;
  }

  saveJson(databaseId: string, rules: Rule[]) {
    writeFileSync(this.jsonPath(databaseId), JSON.stringify(rules, null, 2));
  }

  saveMarkdown(databaseId: string, rules: Rule[]) {
    const lines: string[] = [`# Database Rules: ${databaseId}\n`];

    for (const rule of rules) {
      lines.push(`## ${rule.rule_type} — ${rule.id}\n`);
      if (rule.description) lines.push(`**Description:** ${rule.description}\n`);
      lines.push("```json");
      lines.push(JSON.stringify(rule, null, 2));
      lines.push("```\n");
    }

    writeFileSync(this.mdPath(databaseId), lines.join("\n"));
  }

  /**
   * When rules are stored in RAG Core, the local Markdown file only contains the retrieval strategy.
   */
  async writeRetrievalStrategyMarkdown(
    databaseId: string,
    config: DatabaseConfig | undefined,
    sampleRules: Rule[]
  ) {
    const backend = config?.rule_storage;
    const kbId = backend?.type === "rag_core" ? backend.kb_id : undefined;
    const ragUrl = this.ragClient.getConfig().baseUrl;

    const lines: string[] = [`# Database ${databaseId} — RAG Core 检索策略\n`];
    lines.push(`- **database_id**: \`${databaseId}\``);
    lines.push(`- **存储后端**: RAG Core`);
    lines.push(`- **知识库 ID (kb_id)**: \`${kbId || "未配置"}\``);
    lines.push(`- **服务地址**: \`${ragUrl}\``);
    lines.push(`- **鉴权**: 若启用生产模式，使用 \`Authorization: Bearer <access_key>\`；debug 模式可省略。`);
    lines.push(`\n## 检索规则\n`);
    lines.push("生成 SQL 时，按 `database_id` 过滤后，再按 `rule_type` 检索。");
    lines.push(`\n### 通用检索模板\n`);
    lines.push("```json");
    lines.push(JSON.stringify({
      search_json_configs: [
        {
          kb_id: kbId,
          query: "<自然语言检索词，例如：用户表 性别 映射>",
          top_k: 10,
          ratio: 0.3,
          semantic_keys: [["description"], ["table"], ["col"], ["query"], ["sql"]],
          logical_expression: {
            operator: "and",
            expressions: [
              { field: "database_id", operator: "eq", value: databaseId },
              { field: "rule_type", operator: "eq", value: "<ddl|mapping|example|experience>" },
            ],
          },
        },
      ],
    }, null, 2));
    lines.push("```\n");

    lines.push("### 1. 表结构 DDL\n");
    lines.push("- 逻辑表达式：`database_id == \"" + databaseId + "\" AND rule_type == \"ddl\"`");
    lines.push("- 语义检索字段：`table`, `description`, `ddl`");
    lines.push("- 用于获取表名、列名、主外键、类型等元数据。\n");

    lines.push("### 2. 映射与别名 Mapping\n");
    lines.push("- 逻辑表达式：`database_id == \"" + databaseId + "\" AND rule_type == \"mapping\"`");
    lines.push("- 语义检索字段：`col`, `description`, `mapping_type`, `from`, `to`");
    lines.push("- 若 query 涉及特定表，追加 `table == \"<table>\"` 过滤。\n");

    lines.push("### 3. query→sql 示例 Example\n");
    lines.push("- 逻辑表达式：`database_id == \"" + databaseId + "\" AND rule_type == \"example\"`");
    lines.push("- 语义检索字段：`query`, `sql`, `description`");
    lines.push("- 使用 `top_k` 取最相似示例，作为 few-shot 生成参考。\n");

    lines.push("### 4. 字段经验 Experience\n");
    lines.push("- 逻辑表达式：`database_id == \"" + databaseId + "\" AND rule_type == \"experience\"`");
    lines.push("- 语义检索字段：`description`, `tables[].name`, `tables[].cols`");
    lines.push("- 用于 SQL 生成后的校验与知识图谱验证。\n");

    if (sampleRules.length > 0) {
      lines.push("## 已录入规则示例\n");
      for (const rule of sampleRules.slice(0, 5)) {
        lines.push(`- ${rule.rule_type} (${rule.id}): ${rule.description || ""}`);
      }
    }

    writeFileSync(this.mdPath(databaseId), lines.join("\n"));
  }

  allDatabaseIds(): string[] {
    return readdirSync(RULES_DIR)
      .filter((f) => f.endsWith(".md"))
      .map((f) => f.replace(/\.md$/, ""));
  }
}
