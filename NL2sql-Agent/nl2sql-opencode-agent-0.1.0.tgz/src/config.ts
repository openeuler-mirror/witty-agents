import { existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import path from "node:path";
import { homedir } from "node:os";
import { v4 as uuidv4 } from "uuid";

const CONFIG_DIR = process.env.NL2SQL_CONFIG_DIR ||
  path.join(homedir(), ".config/opencode/nl2sql-agent");
const CONFIG_FILE = path.join(CONFIG_DIR, "databases.json");

export interface RuleStorageBackend {
  type: "local" | "rag_core";
  kb_id?: string;
}

export interface DatabaseConfig {
  id: string;
  type: "mysql" | "postgres" | "sqlite" | string;
  host?: string;
  port?: number;
  username?: string;
  password?: string;
  database?: string;
  file?: string;
  readonly?: boolean;
  rule_storage?: RuleStorageBackend;
  options?: Record<string, unknown>;
}

export class DatabaseConfigManager {
  private static instance: DatabaseConfigManager;
  private configs: Record<string, DatabaseConfig> = {};

  private constructor() {
    this.load();
  }

  static getInstance(): DatabaseConfigManager {
    if (!DatabaseConfigManager.instance) {
      DatabaseConfigManager.instance = new DatabaseConfigManager();
    }
    return DatabaseConfigManager.instance;
  }

  private load() {
    if (existsSync(CONFIG_FILE)) {
      try {
        const raw = readFileSync(CONFIG_FILE, "utf-8");
        this.configs = JSON.parse(raw) || {};
      } catch {
        this.configs = {};
      }
    }
  }

  private save() {
    if (!existsSync(CONFIG_DIR)) {
      mkdirSync(CONFIG_DIR, { recursive: true });
    }
    writeFileSync(CONFIG_FILE, JSON.stringify(this.configs, null, 2), { mode: 0o600 });
  }

  add(config: Omit<DatabaseConfig, "id"> & { id?: string }): DatabaseConfig {
    const id = config.id || uuidv4();
    const full: DatabaseConfig = { ...config, id } as DatabaseConfig;
    this.configs[id] = full;
    this.save();
    return full;
  }

  update(id: string, patch: Partial<DatabaseConfig>): DatabaseConfig | undefined {
    if (!this.configs[id]) return undefined;
    this.configs[id] = { ...this.configs[id], ...patch };
    this.save();
    return this.configs[id];
  }

  get(id: string): DatabaseConfig | undefined {
    return this.configs[id];
  }

  list(): DatabaseConfig[] {
    return Object.values(this.configs);
  }

  remove(id: string): boolean {
    if (!this.configs[id]) return false;
    delete this.configs[id];
    this.save();
    return true;
  }
}
