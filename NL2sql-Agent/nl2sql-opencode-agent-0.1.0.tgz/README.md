# nl2sql-opencode-agent

OpenCode 的 NL2SQL Agent 插件，支持自然语言转 SQL、多态数据库引擎执行、规则库管理（本地 / RAG Core）以及知识图谱验证。

## 功能

- **规则初始化**：根据数据库连接信息（类型、IP、端口、账号、密码、库名）和自然语言诉求，自动生成 NL2SQL 规则库。
- **查询拆解**：借助 `brainstorm-beagle` 对模糊 query 进行隐含信息挖掘，拆解为明确子查询。
- **SQL 生成**：基于规则库（DDL、映射、示例、经验）生成目标 SQL。
- **SQL 执行**：多态 SQL Engine 支持 MySQL、PostgreSQL、SQLite 等，按数据库类型自动选择。
- **结果验证**：使用 `knowledge-graph-agents` 将结果凝练为知识图谱，通过随机游走/多跳推理判断合理性。
- **失败重试**：结果不合理时向用户询问缺失信息，重新生成 SQL。
- **RAG Core 集成**：可将规则拆散存入 `euler-copilot-rag/rag_core` 的 JSON 知识库，本地 Markdown 仅保存检索策略。

## 环境要求

- Node.js >= 18（推荐 Node 20+）
- OpenCode 已安装并启用插件系统

> 数据库驱动（`mysql2`、`pg`、`better-sqlite3`）已声明为 `optionalDependencies`。`npm install` 即使某个驱动因缺少编译工具（如 `g++`）而无法安装，也不会导致整个包安装失败。你只安装实际用到的驱动即可。

## 安装

### 1. 从 tarball 安装（当前方式）

```bash
npm install -g /path/to/nl2sql-opencode-agent-0.1.0.tgz
```

或安装到 OpenCode 的插件目录（推荐）：

```bash
cd ~/.opencode
npm install /path/to/nl2sql-opencode-agent-0.1.0.tgz
```

### 2. 从 npm 安装（发布到 npm 后）

```bash
npm install -g nl2sql-opencode-agent
```

或：

```bash
cd ~/.opencode
npm install nl2sql-opencode-agent
```

### 2. 在 OpenCode 配置中启用插件

编辑 `~/.config/opencode/opencode.jsonc`：

```jsonc
{
  "$schema": "https://opencode.ai/config.json",
  "plugin": [
    "nl2sql-opencode-agent"
  ]
}
```

### 3. 安装依赖 Skill（已随包附带，也可单独安装）

如果只想使用最新版本，也可以单独安装：

```bash
# 安装 SkillHub CLI（如未安装）
curl -fsSL https://skillhub-1388575217.cos.ap-guangzhou.myqcloud.com/install/install.sh | bash -s -- --cli-only

# 安装头脑风暴和知识图谱 Skill
skillhub install brainstorm-beagle --namespace anderskev --dir ~/.config/opencode/skills
skillhub install knowledge-graph-agents --namespace vnesin-sarai --dir ~/.config/opencode/skills
```

> 本包已自带 `@anderskev/brainstorm-beagle` 和 `@vnesin-sarai/knowledge-graph-agents` 两个 Skill 的副本。插件启动时会自动扫描 `skills/` 目录并注册所有独立 skill，无需额外配置。
> 
> 每个 skill 都是独立原子：`nl2sql` skill 不引用其他 skill；skill 之间的协同关系由 `src/role-prompt.md` 在 Agent 层面描述。

### 4. 注册数据库

在 OpenCode 中切换到 `nl2sql` Agent，使用 `/nl2sql-config` 命令注册数据库：

```
/nl2sql-config add
{
  "id": "my-db-001",
  "type": "mysql",
  "host": "127.0.0.1",
  "port": 3306,
  "username": "root",
  "password": "secret",
  "database": "sales",
  "rule_storage": { "type": "local" }
}
```

注册后，Agent 会引导你使用 `brainstorm-beagle` 初始化规则库（DDL、映射、示例、经验）。

### 5. 使用 RAG Core 存储规则（可选）

若已部署 `euler-copilot-rag/rag_core`（默认 `http://localhost:9988`），可将规则存入 JSON 知识库：

1. 配置 RAG Core 地址和密钥（可选）：

   ```bash
   cat > ~/.config/opencode/nl2sql-agent/rag-core.json <<EOF
   {
     "baseUrl": "http://localhost:9988",
     "accessKey": "debug-access-key"
   }
   EOF
   ```

2. 在注册数据库时指定 `rule_storage.type = "rag_core"`，或事后让 Agent 调用初始化工具创建 KB 并写入 `kb_id`。

3. 本地 `skills/nl2sql/rules/<database_id>.md` 将自动变为**检索策略文档**，原始规则写入 RAG Core KB。

## 使用

切换到 `nl2sql` Agent，直接用自然语言提问：

```
最近 7 天注册的女性用户中，年龄大于 25 岁的有多少人？
```

Agent 会执行：

1. 拆解 query 并挖掘隐含信息（“最近 7 天” = 时间范围，“女性” = gender 映射）。
2. 从规则库召回 `mapping` 和 `ddl` 规则。
3. 生成 SQL 并执行。
4. 用知识图谱验证结果合理性。
5. 返回 SQL 和结果摘要。

## 设计原则：Skill 原子化

- `skills/nl2sql/SKILL.md` 只描述 NL2SQL skill 本身的能力（规则、引擎、SQL 生成、结果格式），**不引用其他 skill**。
- `src/role-prompt.md` 描述 `nl2sql` Agent 的协同编排：何时调用 `brainstorm-beagle`、何时使用 `nl2sql` skill、何时使用 `knowledge-graph-agents`。
- `brainstorm-beagle` 和 `knowledge-graph-agents` 作为独立 skill 安装，保持原样不被修改。

## 目录结构

```
nl2sql-opencode-agent/
├── dist/                       # 编译后的插件入口
├── src/                        # TypeScript 源码与 Agent 角色提示
│   ├── index.ts                # 插件入口
│   ├── role-prompt.md          # Agent system prompt（skill 协同编排）
│   ├── config.ts               # 数据库配置管理
│   ├── rule-store.ts           # 规则库读写（本地 JSON / RAG Core）
│   └── rag-core.ts             # RAG Core 服务客户端
├── skills/
│   ├── nl2sql/                 # 原子化 NL2SQL skill
│   │   ├── SKILL.md            # skill 自身能力说明
│   │   ├── _meta.json
│   │   ├── engines/            # 多态 SQL 引擎（技能子目录）
│   │   │   ├── index.js
│   │   │   ├── mysql.js
│   │   │   ├── postgres.js
│   │   │   ├── sqlite.js
│   │   │   └── README.md
│   │   └── rules/              # 规则库（本地文件 + RAG Core 检索策略）
│   │       ├── schema.json
│   │       └── README.md
│   ├── @anderskev/brainstorm-beagle
│   └── @vnesin-sarai/knowledge-graph-agents
├── README.md
├── DESIGN.md
└── package.json
```

## 扩展数据库引擎

在 `skills/nl2sql/engines/` 下新建引擎文件（如 `clickhouse.js`），实现 `SqlEngine` 接口：

```js
export default {
  id: "clickhouse",
  async testConnection(config) { /* ... */ },
  async execute(sql, config) { /* ... */ },
};
```

然后在 `skills/nl2sql/engines/index.js` 的 `loadEngines` 文件列表中注册即可。

## RAG Core 规则检索示例

```bash
# 假设规则已写入 KB，搜索 users 表的 mapping 规则
curl -X POST http://localhost:9988/json/search \
  -H "Content-Type: application/json" \
  -d '{
    "search_json_configs": [{
      "kb_id": "your-kb-id",
      "query": "用户表 性别 映射",
      "top_k": 10,
      "ratio": 0.3,
      "semantic_keys": [["description"], ["table"], ["col"]],
      "logical_expression": {
        "operator": "and",
        "expressions": [
          {"field": "database_id", "operator": "eq", "value": "my-db-001"},
          {"field": "rule_type", "operator": "eq", "value": "mapping"}
        ]
      }
    }]
  }'
```

## 安全提示

- 数据库凭据默认存储在 `~/.config/opencode/nl2sql-agent/databases.json`。
- 建议将该文件权限设为 `600`。
- RAG Core 配置 `rag-core.json` 也可能包含密钥，建议同样设为 `600`。
- 默认只读执行（仅 `SELECT`），避免写入/删除操作。可在配置中显式开启写权限。
- 所有 SQL 执行前会记录到日志，便于审计。

## 协议

MIT
